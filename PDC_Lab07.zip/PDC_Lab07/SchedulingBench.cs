﻿
using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;

class Program
{
    const int N = 1024;
    const int Repeat = 3;

    static double Work(int i, bool uniform)
    {
        int amount = uniform ? 15000 : 1000 + i * 28;
        double result = 0;

        for (int j = 0; j < amount; j++)
            result += Math.Sqrt(j + 1.0) * 0.00001;

        return result;
    }

    static void Main(string[] args)
    {
        int threads = args.Length > 0 ? int.Parse(args[0]) : 4;
        bool uniform = args.Length > 1 &&
                       args[1].Equals("uniform",
                       StringComparison.OrdinalIgnoreCase);

        if (threads < 1)
        {
            Console.WriteLine("Threads must be at least 1.");
            return;
        }

        Console.WriteLine($"Threads={threads}");
        Console.WriteLine($"Logical cores={Environment.ProcessorCount}");
        Console.WriteLine($"Workload={(uniform ? "Uniform" : "Uneven")}");

        string[] policies =
        {
            "static", "static,1", "static,64",
            "dynamic,1", "dynamic,64",
            "guided,1", "guided,64", "Parallel.For"
        };

        double[] reference = new double[N];
        for (int i = 0; i < N; i++)
            reference[i] = Work(i, uniform);

        Console.WriteLine(
            "Policy          Wall(ms)  BusyMax  BusyMin  Imbalance  Correct");

        foreach (string policy in policies)
        {
            double bestWall = double.MaxValue;
            double bestMax = 0;
            double bestMin = 0;
            bool bestCorrect = false;

            for (int run = 0; run < Repeat; run++)
            {
                double[] result = new double[N];
                double[] busy = new double[threads];
                int next = 0;
                Thread[] workers = new Thread[threads];

                Stopwatch wall = Stopwatch.StartNew();

                if (policy == "Parallel.For")
                {
                    Parallel.For(0, N,
                        new ParallelOptions
                        {
                            MaxDegreeOfParallelism = threads
                        },
                        i => result[i] = Work(i, uniform));
                }
                else
                {
                    for (int t = 0; t < threads; t++)
                    {
                        int id = t;

                        workers[t] = new Thread(() =>
                        {
                            Stopwatch timer = Stopwatch.StartNew();

                            void Process(int start, int end)
                            {
                                for (int i = start; i < end; i++)
                                    result[i] = Work(i, uniform);
                            }

                            if (policy == "static")
                            {
                                int start = id * N / threads;
                                int end = (id + 1) * N / threads;
                                Process(start, end);
                            }
                            else if (policy.StartsWith("static,"))
                            {
                                int chunk = int.Parse(policy.Split(',')[1]);

                                for (int start = id * chunk;
                                     start < N;
                                     start += threads * chunk)
                                {
                                    Process(start, Math.Min(start + chunk, N));
                                }
                            }
                            else if (policy.StartsWith("dynamic,"))
                            {
                                int chunk = int.Parse(policy.Split(',')[1]);

                                while (true)
                                {
                                    int start = Interlocked.Add(ref next, chunk)
                                                - chunk;

                                    if (start >= N) break;
                                    Process(start, Math.Min(start + chunk, N));
                                }
                            }
                            else if (policy.StartsWith("guided,"))
                            {
                                int minChunk = int.Parse(policy.Split(',')[1]);

                                while (true)
                                {
                                    int start, end;

                                    lock (result)
                                    {
                                        start = next;
                                        if (start >= N) break;

                                        int remaining = N - next;
                                        int chunk = Math.Max(
                                            minChunk,
                                            (remaining + threads - 1) / threads);

                                        end = Math.Min(N, start + chunk);
                                        next = end;
                                    }

                                    Process(start, end);
                                }
                            }

                            timer.Stop();
                            busy[id] = timer.Elapsed.TotalMilliseconds;
                        });

                        workers[t].Start();
                    }

                    foreach (Thread worker in workers)
                        worker.Join();
                }

                wall.Stop();

                bool correct = true;
                for (int i = 0; i < N; i++)
                {
                    if (Math.Abs(result[i] - reference[i]) > 0.000001)
                    {
                        correct = false;
                        break;
                    }
                }

                double busyMax = 0;
                double busyMin = double.MaxValue;

                if (policy != "Parallel.For")
                {
                    foreach (double b in busy)
                    {
                        busyMax = Math.Max(busyMax, b);
                        busyMin = Math.Min(busyMin, b);
                    }
                }

                if (wall.Elapsed.TotalMilliseconds < bestWall)
                {
                    bestWall = wall.Elapsed.TotalMilliseconds;
                    bestMax = busyMax;
                    bestMin = busyMin;
                    bestCorrect = correct;
                }
            }

            string busyMaxText = policy == "Parallel.For"
                ? "N/A" : bestMax.ToString("F2");

            string busyMinText = policy == "Parallel.For"
                ? "N/A" : bestMin.ToString("F2");

            string imbalance = policy == "Parallel.For"
                ? "N/A" : (bestMax / Math.Max(bestMin, 0.000001)).ToString("F2");

            Console.WriteLine(
                $"{policy,-15} {bestWall,8:F2} " +
                $"{busyMaxText,8} {busyMinText,8} " +
                $"{imbalance,9} {(bestCorrect ? "YES" : "NO")}");
        }
    }
}
