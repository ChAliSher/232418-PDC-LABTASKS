﻿
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;

class Program
{
    const int Iterations = 10_000_000;

    // Separate each counter by 128 bytes
    [StructLayout(LayoutKind.Explicit, Size = 128)]
    struct PaddedCounter
    {
        [FieldOffset(0)]
        public long Value;
    }

    static double RunAdjacent(int threads, out bool correct)
    {
        long[] counters = new long[threads];
        Thread[] workers = new Thread[threads];

        Stopwatch sw = Stopwatch.StartNew();

        for (int t = 0; t < threads; t++)
        {
            int id = t;

            workers[t] = new Thread(() =>
            {
                for (int i = 0; i < Iterations; i++)
                {
                    // Atomic update of an adjacent counter
                    Interlocked.Increment(ref counters[id]);
                }
            });

            workers[t].Start();
        }

        foreach (Thread worker in workers)
            worker.Join();

        sw.Stop();

        correct = true;
        foreach (long count in counters)
            if (count != Iterations) correct = false;

        return sw.Elapsed.TotalMilliseconds;
    }

    static double RunPadded(int threads, out bool correct)
    {
        PaddedCounter[] counters = new PaddedCounter[threads];
        Thread[] workers = new Thread[threads];

        Stopwatch sw = Stopwatch.StartNew();

        for (int t = 0; t < threads; t++)
        {
            int id = t;

            workers[t] = new Thread(() =>
            {
                for (int i = 0; i < Iterations; i++)
                {
                    Interlocked.Increment(ref counters[id].Value);
                }
            });

            workers[t].Start();
        }

        foreach (Thread worker in workers)
            worker.Join();

        sw.Stop();

        correct = true;
        foreach (var counter in counters)
            if (counter.Value != Iterations) correct = false;

        return sw.Elapsed.TotalMilliseconds;
    }

    static double RunLocal(int threads, out bool correct)
    {
        long[] counters = new long[threads];
        Thread[] workers = new Thread[threads];

        Stopwatch sw = Stopwatch.StartNew();

        for (int t = 0; t < threads; t++)
        {
            int id = t;

            workers[t] = new Thread(() =>
            {
                long local = 0;

                for (int i = 0; i < Iterations; i++)
                {
                    local++;
                }

                counters[id] = local;
            });

            workers[t].Start();
        }

        foreach (Thread worker in workers)
            worker.Join();

        sw.Stop();

        correct = true;
        foreach (long count in counters)
            if (count != Iterations) correct = false;

        return sw.Elapsed.TotalMilliseconds;
    }

    static void Main(string[] args)
    {
        int threads = args.Length > 0
            ? int.Parse(args[0]) : 4;

        if (threads < 1)
        {
            Console.WriteLine("Thread count must be at least 1.");
            return;
        }

        Console.WriteLine($"Threads={threads}");
        Console.WriteLine(
            $"Logical cores={Environment.ProcessorCount}");
        Console.WriteLine("Cache line: typically 64 bytes");

        double adjacent = RunAdjacent(threads, out bool a);
        double padded = RunPadded(threads, out bool p);
        double local = RunLocal(threads, out bool l);

        Console.WriteLine("\nResults:");
        Console.WriteLine($"Adjacent: {adjacent:F3} ms");
        Console.WriteLine($"Padded:   {padded:F3} ms");
        Console.WriteLine($"Local:    {local:F3} ms");

        Console.WriteLine(
            $"Counters correct: {(a && p && l ? "YES" : "NO")}");

        Console.WriteLine(
            $"Slowdown adjacent/padded: {adjacent / padded:F2}x");
    }
}
