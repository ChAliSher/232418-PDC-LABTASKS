﻿
using System;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

class Program
{
    const int N = 2_000_000;

    static readonly int[] Data = Enumerable.Range(0, N)
        .Select(i => i % 100 + 1).ToArray();

    static readonly long ExpectedSum = Data.Sum(x => (long)x);
    static readonly int ExpectedMax = Data.Max();

    static int Threads;

    // Version 1: Serial
    static (long sum, int max) Serial()
    {
        long sum = 0;
        int max = int.MinValue;

        foreach (int x in Data)
        {
            sum += x;
            if (x > max) max = x;
        }
        return (sum, max);
    }

    // Version 2: Racy
    static (long sum, int max) Racy()
    {
        long sum = 0;
        int max = int.MinValue;

        Parallel.For(0, N,
            new ParallelOptions { MaxDegreeOfParallelism = Threads },
            i =>
            {
                sum += Data[i];
                if (Data[i] > max) max = Data[i];
            });

        return (sum, max);
    }

    // Version 3: Lock Each
    static (long sum, int max) LockEachVersion()
    {
        long sum = 0;
        int max = int.MinValue;
        object gate = new();

        Parallel.For(0, N,
            new ParallelOptions { MaxDegreeOfParallelism = Threads },
            i =>
            {
                lock (gate)
                {
                    sum += Data[i];
                    if (Data[i] > max) max = Data[i];
                }
            });

        return (sum, max);
    }

    // Version 4: Lock Partial
    static (long sum, int max) LockPartialVersion()
    {
        long sum = 0;
        int max = int.MinValue;
        object gate = new();

        Parallel.For<long[]>(
            0, N,
            new ParallelOptions { MaxDegreeOfParallelism = Threads },
            () => new long[] { 0, int.MinValue },
            (i, state, local) =>
            {
                local[0] += Data[i];
                if (Data[i] > local[1])
                    local[1] = Data[i];

                return local;
            },
            local =>
            {
                lock (gate)
                {
                    sum += local[0];
                    if (local[1] > max)
                        max = (int)local[1];
                }
            });

        return (sum, max);
    }

    // Version 5: PLINQ
    static (long sum, int max) PlinqVersion()
    {
        var q = Data.AsParallel()
            .WithDegreeOfParallelism(Threads);

        return (q.Sum(x => (long)x), q.Max());
    }

    static void Main(string[] args)
    {
        Threads = args.Length > 0
            ? Math.Max(1, int.Parse(args[0])) : 4;

        Console.WriteLine(
            $"Threads={Threads} logical_cores={Environment.ProcessorCount}");

        Console.WriteLine(
            $"Expected Sum={ExpectedSum}, Expected Max={ExpectedMax}");

        var cases = new (string name, Func<(long sum, int max)> run)[]
        {
            ("serial", Serial),
            ("racy", Racy),
            ("lock-each", LockEachVersion),
            ("lock-partial", LockPartialVersion),
            ("plinq", PlinqVersion)
        };

        foreach (var c in cases)
        {
            double total = 0;
            (long sum, int max) answer = default;

            for (int k = 0; k < 3; k++)
            {
                var sw = Stopwatch.StartNew();
                answer = c.run();
                sw.Stop();
                total += sw.Elapsed.TotalMilliseconds;
            }

            Console.WriteLine(
                $"{c.name,-15} sum={answer.sum} max={answer.max} " +
                $"sum_ok={(answer.sum == ExpectedSum ? "YES" : "NO")} " +
                $"max_ok={(answer.max == ExpectedMax ? "YES" : "NO")} " +
                $"avg_ms={total / 3:F3}");
        }
    }
}
